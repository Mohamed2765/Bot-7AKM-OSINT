#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram OSINT Bot - نسخة تفاعلية متكاملة
كل الإعدادات تتم عبر البوت نفسه
"""

import asyncio
import sqlite3
import re
from datetime import datetime, timedelta
from collections import Counter
from typing import Dict, List, Optional

from telethon import TelegramClient
from telethon.errors import FloodWaitError, UsernameNotOccupiedError
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command, StateFilter
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

# ==================== التوكن من @BotFather ====================
BOT_TOKEN = "7969100821:AAG1uu-1uYcuQxpqu1KcfKwlKP_VERsdsfo"
# ===============================================================

# ==================== قاعدة البيانات المحلية ====================
DB_PATH = "osint_bot.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS config (
        key TEXT PRIMARY KEY,
        value TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS username_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        changed_at TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS messages_cache (
        user_id INTEGER,
        text TEXT,
        date TIMESTAMP,
        chat_id INTEGER
    )''')
    conn.commit()
    conn.close()

init_db()

def set_config(key: str, value: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("REPLACE INTO config (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()

def get_config(key: str) -> Optional[str]:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT value FROM config WHERE key = ?", (key,))
    row = c.fetchone()
    conn.close()
    return row[0] if row else None

# ==================== متغيرات Telethon ====================
telethon_client: Optional[TelegramClient] = None

# ==================== FSM للحالة التفاعلية ====================
class SetupStates(StatesGroup):
    waiting_for_api_id = State()
    waiting_for_api_hash = State()
    waiting_for_phone = State()
    waiting_for_code = State()  # سيتم استخدامه لطلب رمز التحقق

# ==================== تهيئة البوت ====================
storage = MemoryStorage()
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=storage)

# ==================== دوال Telethon المساعدة ====================
async def start_telethon(api_id: int, api_hash: str, phone: str):
    global telethon_client
    if telethon_client and telethon_client.is_connected():
        await telethon_client.disconnect()
    telethon_client = TelegramClient('user_session', api_id, api_hash)
    await telethon_client.start(phone=phone)
    me = await telethon_client.get_me()
    return me

# ==================== أزرار تفاعلية بسيطة (اختيارية) ====================
def get_main_keyboard():
    kb = [
        [KeyboardButton(text="ℹ️ معلومات مستخدم"), KeyboardButton(text="📢 قنوات مشتركة")],
        [KeyboardButton(text="📨 تحليل رسائل"), KeyboardButton(text="📊 كلمات متكررة")],
        [KeyboardButton(text="⏰ تحليل النشاط"), KeyboardButton(text="📜 تاريخ الأسماء")],
        [KeyboardButton(text="🔔 مراقبة تغييرات"), KeyboardButton(text="⚙️ إعادة الإعداد")]
    ]
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)

# ==================== أوامر البوت الأساسية ====================
@dp.message(Command("start"))
async def cmd_start(msg: types.Message, state: FSMContext):
    # التحقق مما إذا كانت البيانات موجودة مسبقاً
    if get_config("API_ID") and get_config("API_HASH") and get_config("PHONE"):
        await msg.reply(
            "✨ *بوت OSINT جاهز للعمل* ✨\n\n"
            "يمكنك استخدام الأوامر التالية:\n"
            "• `/info @username` – معلومات شاملة\n"
            "• `/common @username` – القنوات المشتركة\n"
            "• `/messages @username` – تحليل آخر 500 رسالة\n"
            "• `/words` – تحليل الكلمات (بعد تحميل الرسائل)\n"
            "• `/activity` – ساعات النشاط\n"
            "• `/history @username` – تغييرات الأسماء السابقة\n"
            "• `/monitor @username` – مراقبة مستمرة\n"
            "• `/reset` – إعادة تعيين بيانات API\n\n"
            "🔹 *هام*: أول استخدام للتحليل (`/messages`) قد يستغرق دقائق.",
            parse_mode="Markdown",
            reply_markup=get_main_keyboard()
        )
        return

    # إذا لم توجد بيانات، نبدأ خطوات الإعداد
    await msg.reply(
        "🔐 *مرحباً! لنقم بإعداد البوت معاً.* 🔐\n\n"
        "سأطلب منك ثلاث معلومات:\n"
        "1️⃣ `API ID`\n"
        "2️⃣ `API Hash`\n"
        "3️⃣ رقم هاتفك (بالمفتاح الدولي، مثل `+201095539788`)\n\n"
        "كل هذه البيانات تحصل عليها من [my.telegram.org](https://my.telegram.org/apps).\n\n"
        "✨ *أرسل الآن API ID (عدد صحيح)*",
        parse_mode="Markdown",
        disable_web_page_preview=True
    )
    await state.set_state(SetupStates.waiting_for_api_id)

@dp.message(StateFilter(SetupStates.waiting_for_api_id))
async def get_api_id(msg: types.Message, state: FSMContext):
    if not msg.text.isdigit():
        await msg.reply("❌ *API ID* يجب أن يكون أرقاماً فقط. حاول مرة أخرى:")
        return
    api_id = int(msg.text)
    await state.update_data(api_id=api_id)
    set_config("API_ID", str(api_id))
    await msg.reply("✅ تم حفظ *API ID*.\n📎 أرسل الآن *API Hash* (سلسلة نصية طويلة):")
    await state.set_state(SetupStates.waiting_for_api_hash)

@dp.message(StateFilter(SetupStates.waiting_for_api_hash))
async def get_api_hash(msg: types.Message, state: FSMContext):
    api_hash = msg.text.strip()
    if len(api_hash) < 10:
        await msg.reply("❌ *API Hash* يبدو قصيراً جداً. تأكد من نسخه كاملاً وأرسله مرة أخرى:")
        return
    await state.update_data(api_hash=api_hash)
    set_config("API_HASH", api_hash)
    await msg.reply("✅ تم حفظ *API Hash*.\n📱 أرسل الآن رقم هاتفك بالتنسيق الدولي (مثال: `+201095539788`):")
    await state.set_state(SetupStates.waiting_for_phone)

@dp.message(StateFilter(SetupStates.waiting_for_phone))
async def get_phone(msg: types.Message, state: FSMContext):
    phone = msg.text.strip()
    if not phone.startswith("+") or not phone[1:].isdigit():
        await msg.reply("❌ الرقم يجب أن يبدأ بـ `+` متبوعاً بالأرقام فقط.\nمثال: `+201234567890`\nحاول مرة أخرى:")
        return
    await state.update_data(phone=phone)
    set_config("PHONE", phone)
    data = await state.get_data()
    api_id = data.get("api_id")
    api_hash = data.get("api_hash")
    # محاولة تسجيل الدخول إلى Telethon
    try:
        await msg.reply("🔄 جاري الاتصال بخوادم تيليجرام...")
        global telethon_client
        telethon_client = TelegramClient('user_session', api_id, api_hash)
        await telethon_client.connect()
        if not await telethon_client.is_user_authorized():
            # إرسال رمز التحقق
            await telethon_client.send_code_request(phone)
            await msg.reply(
                "📨 *تم إرسال رمز التحقق إلى تيليجرام*\n"
                "الرجاء إدخال الرمز (الأرقام فقط):",
                parse_mode="Markdown"
            )
            await state.set_state(SetupStates.waiting_for_code)
            return
        else:
            me = await telethon_client.get_me()
            await msg.reply(
                f"✅ *تم تسجيل الدخول بنجاح!*\n"
                f"مرحباً {me.first_name} (@{me.username or 'لا يوجد'})\n"
                f"البوت جاهز الآن للاستخدام. أرسل `/start` مرة أخرى لرؤية الأوامر.",
                parse_mode="Markdown",
                reply_markup=get_main_keyboard()
            )
            await state.clear()
    except Exception as e:
        await msg.reply(f"❌ خطأ أثناء الاتصال: {str(e)[:200]}\nيرجى التحقق من البيانات وإعادة استخدام /start")
        await state.clear()

@dp.message(StateFilter(SetupStates.waiting_for_code))
async def get_code(msg: types.Message, state: FSMContext):
    code = msg.text.strip()
    if not code.isdigit():
        await msg.reply("❌ الرمز يتكون من أرقام فقط، حاول مرة أخرى:")
        return
    data = await state.get_data()
    phone = data.get("phone")
    try:
        await telethon_client.sign_in(phone, code)
        me = await telethon_client.get_me()
        await msg.reply(
            f"✅ *تم تسجيل الدخول بنجاح!*\n"
            f"مرحباً {me.first_name} (@{me.username or 'لا يوجد'})\n"
            f"البوت جاهز الآن. أرسل `/start` للأوامر.",
            parse_mode="Markdown",
            reply_markup=get_main_keyboard()
        )
        await state.clear()
    except Exception as e:
        await msg.reply(f"❌ رمز غير صحيح أو انتهت صلاحيته: {str(e)[:200]}\nاستخدم /start لبدء الإعداد من جديد.")
        await state.clear()

# ==================== أمر إعادة الإعداد ====================
@dp.message(Command("reset"))
async def reset_cmd(msg: types.Message, state: FSMContext):
    set_config("API_ID", "")
    set_config("API_HASH", "")
    set_config("PHONE", "")
    if telethon_client and telethon_client.is_connected():
        await telethon_client.disconnect()
    await state.clear()
    await msg.reply("🔄 تم مسح جميع البيانات. استخدم /start لإعداد البوت من جديد.", reply_markup=ReplyKeyboardRemove())

# ==================== أمر info ====================
@dp.message(Command("info"))
async def info_cmd(msg: types.Message):
    if not telethon_client or not telethon_client.is_connected():
        await msg.reply("❌ البوت غير متصل. تأكد من إتمام الإعداد عبر /start")
        return
    parts = msg.text.split(maxsplit=1)
    if len(parts) < 2:
        await msg.reply("📝 استخدم: `/info @username` أو `/info +رقم` أو `/info 123456789`", parse_mode="Markdown")
        return
    target = parts[1].strip()
    await msg.reply(f"🔍 *جمع معلومات عن* `{target}` ... قد يستغرق ثوانٍ.", parse_mode="Markdown")
    try:
        entity = await telethon_client.get_entity(target)
        full = await telethon_client.get_entity(entity)
        bio = getattr(full, 'about', None)
        response = (
            f"👤 *{full.first_name or ''} {full.last_name or ''}*\n"
            f"🆔 `{full.id}`\n"
            f"📝 @{full.username or 'لا يوجد'}\n"
            f"📱 {getattr(full, 'phone', 'مخفي')}\n"
            f"📝 *السيرة:* {bio[:300] if bio else 'لا توجد'}\n"
            f"✅ موثق: {'✔️ نعم' if full.verified else '❌ لا'}\n"
            f"🤖 بوت: {'نعم' if full.bot else 'لا'}\n"
            f"🌐 مركز البيانات: {getattr(full, 'dc_id', 'غير معروف')}"
        )
        await msg.reply(response, parse_mode="Markdown")
    except UsernameNotOccupiedError:
        await msg.reply("❌ المستخدم غير موجود.")
    except Exception as e:
        await msg.reply(f"⚠️ خطأ: {str(e)[:200]}")

# ==================== أمر common ====================
@dp.message(Command("common"))
async def common_cmd(msg: types.Message):
    if not telethon_client or not telethon_client.is_connected():
        await msg.reply("❌ البوت غير متصل.")
        return
    parts = msg.text.split(maxsplit=1)
    if len(parts) < 2:
        await msg.reply("استخدم: `/common @username`", parse_mode="Markdown")
        return
    target = parts[1].strip()
    await msg.reply(f"🔍 *البحث عن قنوات مشتركة مع* `{target}` ...", parse_mode="Markdown")
    try:
        entity = await telethon_client.get_entity(target)
        common = await telethon_client.get_common_chats(entity)
        if not common:
            await msg.reply("ℹ️ لا توجد قنوات أو مجموعات عامة مشتركة.")
            return
        resp = f"📢 *القنوات/المجموعات المشتركة العامة ({len(common)})*\n\n"
        for c in common[:40]:
            ctype = "قناة" if getattr(c, 'broadcast', False) else ("سوبر جروب" if getattr(c, 'megagroup', False) else "جروب")
            resp += f"• [{c.title}](https://t.me/{c.username}) ({ctype})\n" if c.username else f"• {c.title} ({ctype})\n"
        await msg.reply(resp, parse_mode="Markdown", disable_web_page_preview=True)
    except Exception as e:
        await msg.reply(f"⚠️ خطأ: {str(e)[:200]}")

# ==================== أمر messages (جلب الرسائل مؤقتاً) ====================
# سنخزن الرسائل مؤقتاً لكل مستخدم في قاموس بسيط
user_messages_cache = {}

@dp.message(Command("messages"))
async def messages_cmd(msg: types.Message):
    if not telethon_client or not telethon_client.is_connected():
        await msg.reply("❌ البوت غير متصل.")
        return
    parts = msg.text.split(maxsplit=1)
    if len(parts) < 2:
        await msg.reply("استخدم: `/messages @username` (سيجلب آخر 500 رسالة)\nيمكنك إضافة عدد: `/messages @username 1000`", parse_mode="Markdown")
        return
    args = parts[1].split()
    target = args[0]
    limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 500
    limit = min(limit, 1500)
    await msg.reply(f"📨 *جاري تحميل آخر {limit} رسالة من* `{target}` ...\nقد يستغرق عدة دقائق ⏳", parse_mode="Markdown")
    try:
        entity = await telethon_client.get_entity(target)
        user_id = entity.id
        messages = []
        async for m in telethon_client.iter_messages(entity, limit=limit):
            if m.text:
                messages.append({
                    "text": m.text,
                    "date": m.date,
                    "chat_id": m.chat_id
                })
        if not messages:
            await msg.reply("ℹ️ لم يتم العثور على رسائل نصية.")
            return
        user_messages_cache[msg.from_user.id] = messages
        # تحليل أولي للكلمات والنشاط ووضعها في ذاكرة مؤقتة
        # تحليل الكلمات
        all_text = " ".join([m["text"] for m in messages])
        words = re.findall(r'\b\w{3,}\b', all_text.lower())
        stopwords = {'و', 'في', 'من', 'الى', 'على', 'عن', 'مع', 'لا', 'ما', 'هذا', 'ذلك', 'كان', 'قال', 'هو', 'هي', 'هم', 'الي', 'علي', 'بعد', 'قبل', 'ثم', 'عند'}
        filtered = [w for w in words if w not in stopwords]
        counter = Counter(filtered).most_common(20)
        # تحليل النشاط
        hours = Counter()
        days = Counter()
        for m in messages:
            if m["date"]:
                hours[m["date"].hour] += 1
                days[m["date"].strftime('%A')] += 1
        most_hour = max(hours, key=hours.get) if hours else 0
        most_day = max(days, key=days.get) if days else "غير معروف"
        # تخزين في مؤقت للاستخدام لاحقاً
        user_messages_cache[f"{msg.from_user.id}_words"] = counter
        user_messages_cache[f"{msg.from_user.id}_activity"] = {"hours": hours, "days": days}
        await msg.reply(
            f"✅ *تم تحميل {len(messages)} رسالة بنجاح!*\n\n"
            f"🔹 استخدم `/words` لعرض أكثر الكلمات تكراراً\n"
            f"🔹 استخدم `/activity` لعرض ساعات وأيام النشاط\n"
            f"🔹 يمكنك الآن تنفيذ أوامر التحليل على هذه البيانات.",
            parse_mode="Markdown"
        )
    except Exception as e:
        await msg.reply(f"⚠️ خطأ أثناء جلب الرسائل: {str(e)[:200]}")

@dp.message(Command("words"))
async def words_cmd(msg: types.Message):
    key = f"{msg.from_user.id}_words"
    if key not in user_messages_cache:
        await msg.reply("⚠️ لم تقم بتحميل رسائل بعد. استخدم `/messages @username` أولاً.", parse_mode="Markdown")
        return
    counter = user_messages_cache[key]
    if not counter:
        await msg.reply("لا توجد بيانات كلمات.")
        return
    resp = "📊 *أكثر الكلمات تكراراً:*\n"
    for word, freq in counter[:20]:
        resp += f"• `{word}` : {freq} مرة\n"
    await msg.reply(resp, parse_mode="Markdown")

@dp.message(Command("activity"))
async def activity_cmd(msg: types.Message):
    key = f"{msg.from_user.id}_activity"
    if key not in user_messages_cache:
        await msg.reply("⚠️ قم أولاً بتحميل الرسائل عبر `/messages @username`.", parse_mode="Markdown")
        return
    data = user_messages_cache[key]
    hours = data.get("hours", {})
    days = data.get("days", {})
    if not hours:
        await msg.reply("لا توجد بيانات نشاط.")
        return
    most_hour = max(hours, key=hours.get)
    most_day = max(days, key=days.get) if days else "غير معروف"
    resp = f"🕒 *ساعة الذروة:* {most_hour}:00 ({hours[most_hour]} رسالة)\n"
    resp += f"📅 *أكثر يوم نشاط:* {most_day}\n\n"
    resp += "توزيع الساعات (أعلى 5):\n" + "\n".join([f"{h:02d}:00 → {c} رسالة" for h,c in sorted(hours.items(), key=lambda x: -x[1])[:5]])
    await msg.reply(resp, parse_mode="Markdown")

# ==================== أمر history (تغييرات الأسماء) ====================
# ملاحظة: هذه البيانات تُجمع عند استخدام /monitor فقط. سنضيف خياراً لجمع تاريخ من قاعدة البيانات.
# نضيف أيضاً واجهة لتخزين التغييرات فوراً عند أول استعلام /info (لحفظ الحالة الحالية)
@dp.message(Command("history"))
async def history_cmd(msg: types.Message):
    if not telethon_client or not telethon_client.is_connected():
        await msg.reply("❌ البوت غير متصل.")
        return
    parts = msg.text.split(maxsplit=1)
    if len(parts) < 2:
        await msg.reply("استخدم: `/history @username`", parse_mode="Markdown")
        return
    target = parts[1].strip()
    await msg.reply(f"📜 *جلب سجل تغييرات اسم* `{target}` ...", parse_mode="Markdown")
    try:
        entity = await telethon_client.get_entity(target)
        user_id = entity.id
        # نبحث في قاعدة البيانات عن تغييرات سابقة
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT username, first_name, last_name, changed_at FROM username_history WHERE user_id=? ORDER BY changed_at ASC", (user_id,))
        rows = c.fetchall()
        conn.close()
        if not rows:
            await msg.reply("ℹ️ لا يوجد سجل لتغييرات الأسماء لهذا المستخدم. استخدم `/monore` لبدء المراقبة.")
            return
        resp = f"📜 *سجل تغييرات {entity.first_name or entity.username}*\n\n"
        for r in rows[-15:]:
            resp += f"• `{r[0] or 'بدون'}` | {r[1] or ''} {r[2] or ''} — {r[3][:19]}\n"
        await msg.reply(resp, parse_mode="Markdown")
    except Exception as e:
        await msg.reply(f"⚠️ خطأ: {str(e)[:200]}")

# ==================== أمر monitor (مراقبة دورية) ====================
monitor_tasks = {}

@dp.message(Command("monitor"))
async def monitor_cmd(msg: types.Message):
    if not telethon_client or not telethon_client.is_connected():
        await msg.reply("❌ البوت غير متصل.")
        return
    parts = msg.text.split(maxsplit=1)
    if len(parts) < 2:
        await msg.reply("استخدم: `/monitor @username`\nسيتم مراقبة التغييرات كل ساعة.", parse_mode="Markdown")
        return
    target = parts[1].strip()
    await msg.reply(f"🔔 *بدء المراقبة على* `{target}` ... سيتم إشعارك عند أي تغيير في الاسم أو اليوزرنيم.", parse_mode="Markdown")
    # تشغيل مهمة خلفية
    async def monitor_worker(chat_id, user_identifier):
        last_state = None
        while True:
            try:
                entity = await telethon_client.get_entity(user_identifier)
                current = {
                    "username": entity.username,
                    "first_name": entity.first_name,
                    "last_name": entity.last_name
                }
                if last_state is None:
                    last_state = current
                    # حفظ الحالة الأولى في قاعدة البيانات
                    conn = sqlite3.connect(DB_PATH)
                    c = conn.cursor()
                    c.execute("INSERT INTO username_history (user_id, username, first_name, last_name, changed_at) VALUES (?,?,?,?,?)",
                              (entity.id, current["username"], current["first_name"], current["last_name"], datetime.utcnow()))
                    conn.commit()
                    conn.close()
                else:
                    changes = []
                    if last_state["username"] != current["username"]:
                        changes.append(f"يوزرنيم: {last_state['username']} → {current['username']}")
                    if last_state["first_name"] != current["first_name"]:
                        changes.append(f"الاسم الأول: {last_state['first_name']} → {current['first_name']}")
                    if last_state["last_name"] != current["last_name"]:
                        changes.append(f"الاسم الأخير: {last_state['last_name']} → {current['last_name']}")
                    if changes:
                        # حفظ التغيير
                        conn = sqlite3.connect(DB_PATH)
                        c = conn.cursor()
                        c.execute("INSERT INTO username_history (user_id, username, first_name, last_name, changed_at) VALUES (?,?,?,?,?)",
                                  (entity.id, current["username"], current["first_name"], current["last_name"], datetime.utcnow()))
                        conn.commit()
                        conn.close()
                        # إرسال إشعار
                        await bot.send_message(chat_id, f"🔔 *تغيير في {user_identifier}*\n" + "\n".join(changes), parse_mode="Markdown")
                    last_state = current
                await asyncio.sleep(3600)  # كل ساعة
            except Exception as e:
                await bot.send_message(chat_id, f"⚠️ خطأ في مراقبة {user_identifier}: {str(e)[:200]}")
                await asyncio.sleep(3600)
    task = asyncio.create_task(monitor_worker(msg.chat.id, target))
    monitor_tasks[(msg.chat.id, target)] = task

# ==================== معالجة الأزرار (اختياري) ====================
@dp.message(lambda msg: msg.text == "ℹ️ معلومات مستخدم")
async def btn_info(msg: types.Message):
    await msg.reply("أرسل `/info @username`")

@dp.message(lambda msg: msg.text == "📢 قنوات مشتركة")
async def btn_common(msg: types.Message):
    await msg.reply("أرسل `/common @username`")

@dp.message(lambda msg: msg.text == "📨 تحليل رسائل")
async def btn_messages(msg: types.Message):
    await msg.reply("أرسل `/messages @username`")

@dp.message(lambda msg: msg.text == "📊 كلمات متكررة")
async def btn_words(msg: types.Message):
    await msg.reply("استخدم `/words` بعد تحميل الرسائل")

@dp.message(lambda msg: msg.text == "⏰ تحليل النشاط")
async def btn_activity(msg: types.Message):
    await msg.reply("استخدم `/activity` بعد تحميل الرسائل")

@dp.message(lambda msg: msg.text == "📜 تاريخ الأسماء")
async def btn_history(msg: types.Message):
    await msg.reply("أرسل `/history @username`")

@dp.message(lambda msg: msg.text == "🔔 مراقبة تغييرات")
async def btn_monitor(msg: types.Message):
    await msg.reply("أرسل `/monitor @username`")

@dp.message(lambda msg: msg.text == "⚙️ إعادة الإعداد")
async def btn_reset(msg: types.Message):
    await reset_cmd(msg, None)

# ==================== تشغيل البوت ====================
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())